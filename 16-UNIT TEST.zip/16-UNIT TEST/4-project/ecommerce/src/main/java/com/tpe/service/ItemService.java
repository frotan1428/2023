package com.tpe.service;

import com.tpe.domain.Category;
import com.tpe.domain.Item;
import com.tpe.dto.request.ItemRequestDTO;
import com.tpe.repository.CategoryRepository;
import com.tpe.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;



    @Autowired
    private CategoryService categoryService;

    public void saveItem(ItemRequestDTO itemRequestDTO) {

        //using long id from itemRequestDTO, we are finding Category obj from database
        Category category = categoryService.getCategoryEntityById(itemRequestDTO.getCategory_id());

        Item newItem = new Item();
        newItem.setName(itemRequestDTO.getName());
        newItem.setPrice(itemRequestDTO.getPrice());
        newItem.setDescription(itemRequestDTO.getDescription());
        newItem.setCategory(category);

        itemRepository.save(newItem);


    }
}
