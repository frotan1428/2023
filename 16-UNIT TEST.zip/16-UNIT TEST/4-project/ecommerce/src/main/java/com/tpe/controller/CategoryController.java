package com.tpe.controller;

import com.tpe.dto.request.CategoryRequestDTO;
import com.tpe.dto.response.CategoryResponseDTO;
import com.tpe.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/category")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;


    @PostMapping
    public ResponseEntity<CategoryResponseDTO> addCategory(@Valid @RequestBody CategoryRequestDTO categoryRequestDTO){
        CategoryResponseDTO responseDTO = categoryService.saveCategory(categoryRequestDTO);
        return ResponseEntity.ok(responseDTO);
    }

    //http://localhost:8081/category/2
    @GetMapping("/{id}")

    public ResponseEntity<CategoryResponseDTO> getCategoryById(@PathVariable("id") Long id){

        CategoryResponseDTO responseDTO = categoryService.findCategoryById(id);
        return ResponseEntity.ok(responseDTO);
    }

    //get Category By page (we need to send CategoryDTO by page)

    //http://localhost:8081/category/page?page=0&size=1&sort=name&direction=ASC

    @GetMapping("/page")
    public ResponseEntity<Page<CategoryResponseDTO>> getCategoryByPage(@RequestParam("page") int page,
                                                                       @RequestParam("size") int size,
                                                                       @RequestParam("sort") String prop,
                                                                       @RequestParam("direction")Sort.Direction direction){
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, prop));

        Page<CategoryResponseDTO> responseDTOS= categoryService.getCategoriesByPage(pageable);

        return ResponseEntity.ok(responseDTOS);

    }

    //TODO write methods for  deleting and updating category

}
