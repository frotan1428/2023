package com.tpe.controller;

import com.tpe.dto.request.ItemRequestDTO;
import com.tpe.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/item")
public class ItemController {

    @Autowired
    private ItemService itemService;


    /*

    http://localhost:8081/item

        {
            "name":"Iphone 12",
            "description":"bla bla bla",
            "price": 1000,
            "category_id": "1"
        }
     */

    @PostMapping
    public ResponseEntity<String> createItem(@Valid @RequestBody ItemRequestDTO itemRequestDTO){

        itemService.saveItem(itemRequestDTO);

        String message = "You have saved the item successfully.";
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }
}
