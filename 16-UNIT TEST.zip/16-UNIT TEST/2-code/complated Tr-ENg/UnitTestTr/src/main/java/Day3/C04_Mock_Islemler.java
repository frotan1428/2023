package Day3;

public class C04_Mock_Islemler {

    public void ekleOgrenci(String ogrenciAdi) {
        System.out.println("Öğrenci eklendi..");
    }

    public void silOgrenci(String ogrenciAdi){

        System.out.println("Öğrenci kaydı silindi..");

    }

    public void guncelleOgrenci(String ogrenciAdi) {

        System.out.println("Öğrenci bilgileri güncellendi");
    }
}
